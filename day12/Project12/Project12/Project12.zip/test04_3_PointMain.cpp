// date : 2024-03-08
// file : test04_3_PointTempl.cpp
// desc : p.545

/*
#include <iostream>
#include "test04_1_PointTempl.h"
#include "test04_2_PointTempl.cpp"

using namespace std;

int main(void)
{
	Point<int> pos1(3, 4);
	pos1.ShowPosition();

	Point<int> pos2(2.4, 3.6);
	pos2.ShowPosition();

	Point<int> pos3('P', 'F');
	pos3.ShowPosition();
	return 0;
}
*/